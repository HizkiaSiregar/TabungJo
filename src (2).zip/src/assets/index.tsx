// assets/index.ts
const Logo = require('./LogoTabungJo.png');
const NullPhoto = require('./null-photo.png');
const SaveImage = require('./save-image.png');

export {Logo, NullPhoto, SaveImage};
